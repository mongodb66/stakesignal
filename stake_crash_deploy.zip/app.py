
from flask import Flask, render_template, request, redirect, url_for, session, send_file
import pandas as pd
import os
import json
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

@app.before_request
def require_login():
    if request.endpoint not in ("login", "static") and not session.get("logged_in"):
        return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form["password"] == "yourpassword":
            session["logged_in"] = True
            return redirect("/")
    return render_template("login.html")

@app.route("/")
def index():
    log_file = "crash_log.csv"
    history = []
    chart_data = {"timestamps": [], "crash": [], "ml_prob": []}
    if os.path.exists(log_file):
        df = pd.read_csv(log_file)
        df["Timestamp"] = pd.to_datetime(df["Timestamp"])
        df = df.tail(50)
        history = df.to_dict(orient="records")
        chart_data = {
            "timestamps": df["Timestamp"].dt.strftime("%H:%M:%S").tolist(),
            "crash": df["LastCrash"].tolist(),
            "ml_prob": df["ML_Prob"].tolist(),
        }
        last_row = history[-1]
    else:
        last_row = {"LastCrash": "N/A", "Average": "N/A", "LossStreak": "N/A", "ML_Prob": "N/A", "Suggestion": "N/A"}

    if os.path.exists("balance.json"):
        with open("balance.json") as f:
            balance = json.load(f)
        last_profit = balance["profit_log"][-10:] if balance["profit_log"] else []
    else:
        balance = {"current_balance": 0, "starting_balance": 0}
        last_profit = []

    return render_template("index.html", last=last_row, history=history, chart_data=chart_data,
                           balance=balance, profit=last_profit)

@app.route("/settings", methods=["GET", "POST"])
def settings():
    settings_file = "settings.json"
    if request.method == "POST":
        data = {
            "MIN_PERCENT_ABOVE_2X": float(request.form["MIN_PERCENT_ABOVE_2X"]),
            "MIN_LOSS_STREAK": int(request.form["MIN_LOSS_STREAK"]),
            "ML_BET_THRESHOLD": float(request.form["ML_BET_THRESHOLD"]),
            "LOG_TO_FILE": "LOG_TO_FILE" in request.form,
            "TELEGRAM_ENABLED": "TELEGRAM_ENABLED" in request.form,
            "STRATEGY": request.form["STRATEGY"]
        }
        with open(settings_file, "w") as f:
            json.dump(data, f, indent=2)
        return redirect(url_for("settings"))
    else:
        with open(settings_file) as f:
            config = json.load(f)
        return render_template("settings.html", config=config)

@app.route("/reset", methods=["POST"])
def reset():
    t = request.form["target"]
    if t == "balance":
        with open("balance.json", "w") as f:
            f.write('{"starting_balance": 100.0, "current_balance": 100.0, "stake": 1.0, "profit_log": []}')
    elif t == "settings":
        with open("settings.json", "w") as f:
            f.write('{"MIN_PERCENT_ABOVE_2X": 50.0, "MIN_LOSS_STREAK": 2, "ML_BET_THRESHOLD": 0.5, "LOG_TO_FILE": true, "TELEGRAM_ENABLED": true, "STRATEGY": "combined"}')
    elif t == "logs":
        open("crash_log.csv", "w").write("")
    return redirect("/settings")

@app.route("/download")
def download():
    return send_file("crash_log.csv", as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
